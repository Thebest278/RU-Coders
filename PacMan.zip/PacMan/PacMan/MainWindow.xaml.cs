﻿using System;
using System.Collections.Generic;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media.Imaging;
using System.Windows.Threading;


namespace PacMan
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>

    public class Ghost
    {
        public Image pic { get; set; }
        public int X { get; set; }
        public int Y { get; set; }
        public Canvas can { get; set; }
        public enum Direction { Left, Right, Up, Down };
        Direction facing { get; set; }

        public Ghost(Image p, char colour, Canvas canv)
        {
            pic = p;
            X = 10;
            Y = 10;
            can = canv;
            Random r = new Random();
            pic.IsEnabled = true;
            int pink = r.Next(0, 4);
            int red = r.Next(0, 4);
            int yellow = r.Next(0, 4);

            switch (colour)
            {
                case 'p': { facing = (Direction)pink; break; }
                case 'y': { facing = (Direction)yellow; break; }
                case 'r': { facing = (Direction)red; break; }
            }
        }
        public void Move()
        {
            double next;
            Walls();
            switch (facing)
            {
                case Direction.Left: { next = (Canvas.GetLeft(pic) - X); Canvas.SetLeft(pic, next); break; }
                case Direction.Right: { next = (Canvas.GetLeft(pic) + X); Canvas.SetLeft(pic, next); break; }
                case Direction.Up: { next = (Canvas.GetTop(pic) - Y); Canvas.SetTop(pic, next); break; }
                case Direction.Down: { next = (Canvas.GetTop(pic) + Y); Canvas.SetTop(pic, next); break; }
            }
        }
        private void Walls()
        {

            Random r = new Random();
            int d;
            switch (facing)
            {
                case Direction.Down:
                    {

                        if (Canvas.GetTop(pic) + pic.ActualHeight + Y >= can.ActualHeight) { d = r.Next(0, 3); facing = (Direction)d; }
                        break;
                    }
                case Direction.Up:
                    {

                        if (Canvas.GetTop(pic) - Y <= 0) { d = 2; do { d = r.Next(0, 4); } while (d == 2); facing = (Direction)d; }
                        break;
                    }
                case Direction.Left:
                    {

                        if (Canvas.GetLeft(pic) - X <= 0) { d = r.Next(1, 4); facing = (Direction)d; }
                        break;
                    }
                case Direction.Right:
                    {

                        if (Canvas.GetLeft(pic) + pic.ActualWidth + X >= can.ActualWidth) { d = 1; do { d = r.Next(0, 4); } while (d == 1); facing = (Direction)d; }
                        break;
                    }
            }
        }
    }
    public class Coin
    {
        public Image Pic { get; set; }
        public List<BitmapImage> AllPic { get; set; }
        public Canvas can { get; set; }
        public int points { get; protected set; }
        public Coin(Image p, List<BitmapImage> l, Canvas c, int x, int y)
        {
            Pic = p;
            AllPic = l;
            Pic.Source = AllPic[0];
            can = c;
            points = 100;
            Pic.Visibility = Visibility.Visible;
            
            Canvas.SetLeft(Pic, x);
            Canvas.SetTop(Pic, y);
        }
        

    }
    public class SuperCoin : Coin
    {
        private int Cos;
        public Image Key { get; set; }
        public SuperCoin(Image p, List<BitmapImage> l, Canvas c, Image k, int x, int y) : base(p, l, c, x, y)
        {

            points = 1000;
            Key = k;
            p.Width = 70;
            p.Height = 70;

        }
        public void MakeKey(BitmapImage x)
        {

            Random r = new Random();
            int k = Convert.ToInt32(can.ActualWidth) - 5;
            int KeyLeft = r.Next(5, k);
            k = Convert.ToInt32(can.ActualHeight) - 5;
            int KeyTop = r.Next(5, k);
            Key.Source = x;
            Key.Width = 50;
            Key.Height = 50;
            Canvas.SetTop(Key, KeyTop);
            Key.Visibility = Visibility.Visible;

            Key.IsEnabled = true;

        }
        public void Spin()
        {
            if (Cos != 2)
            {
                Cos++;
            }
            else Cos = 0;
            Pic.Source = AllPic[Cos];
        }
    }

    public class Player
    {

        public enum Moving { Up, Down, Left, Right, Stopped }
        public List<BitmapImage> Pic { get; set; }
        public Image CurrentPic { get; set; }
        private int X { get; set; }
        private int Y { get; set; }
        public Canvas can { get; set; }
        Moving facing { get; set; }
        public int Points { get; private set; }
        public int Lives { get; private set; }
        public Player(List<BitmapImage> x, Canvas c, Image d)
        {
            X = 9;
            Y = 9;
            CurrentPic = d;
            Lives = 3;
            Pic = x;
            facing = Moving.Down;
            ChangeDirection();
            can = c;

        }
        public void Move(char pressed)
        {

            switch (pressed)
            {
                case 'l':
                    {
                        facing = Moving.Left;
                        ChangeDirection();
                        if (Canvas.GetLeft(CurrentPic) > 0)
                        {
                            Canvas.SetLeft(CurrentPic, (Canvas.GetLeft(CurrentPic) - X));
                        }
                        else facing = Moving.Stopped;
                        break;
                    }
                case 'r':
                    {
                        facing = Moving.Right;
                        ChangeDirection();
                        if (Canvas.GetLeft(CurrentPic) + CurrentPic.ActualWidth + X < can.ActualWidth)
                        {
                            Canvas.SetLeft(CurrentPic, (Canvas.GetLeft(CurrentPic) + X));
                        }
                        else facing = Moving.Stopped;
                        break;
                    }
                case 'd':
                    {
                        facing = Moving.Down;
                        ChangeDirection();
                        if (Canvas.GetTop(CurrentPic) + CurrentPic.ActualHeight + Y < can.ActualHeight)
                        {
                            Canvas.SetTop(CurrentPic, (Canvas.GetTop(CurrentPic) + Y));
                        }
                        else facing = Moving.Stopped;
                        break;
                    }
                case 'u':
                    {
                        facing = Moving.Up;
                        ChangeDirection();
                        if (Canvas.GetTop(CurrentPic) > 0)
                        {
                            Canvas.SetTop(CurrentPic, (Canvas.GetTop(CurrentPic) - Y));
                        }
                        else facing = Moving.Stopped;
                        break;
                    }
            }
        }
        private void ChangeDirection()
        {
            switch (facing)
            {

                case Moving.Up: { CurrentPic.Source = Pic[0]; break; }
                case Moving.Down: { CurrentPic.Source = Pic[1]; break; }
                case Moving.Left: { CurrentPic.Source = Pic[3]; break; }
                case Moving.Right: { CurrentPic.Source = Pic[2]; break; }

            }

        }
        public void PointsUp(int p)
        {
            Points = Points + p;
        }
        public void Die()
        {
            Lives--;
            
            Canvas.SetLeft(CurrentPic, 100);
            
            Canvas.SetTop(CurrentPic, 100);
        }
    }

    public partial class MainWindow : Window
    {
        DispatcherTimer theTimer;
        Ghost YellowGhost;
        Ghost RedGhost;
        Ghost PinkGhost;
        Player One;
        bool Starter;
        char Move;
        int Level;
        List<Coin> Coins = new List<Coin> { };
        SuperCoin SUper;
        List<BitmapImage> SC = new List<BitmapImage> { };
        public MainWindow()
        {
            InitializeComponent();

            theTimer = new DispatcherTimer();
            theTimer.Interval = TimeSpan.FromMilliseconds(100);
            theTimer.IsEnabled = false;
            theTimer.Tick += DispatcherTimer_Tick;
            YellowGhost = new Ghost(Yellow, 'y', Background);
            RedGhost = new Ghost(Red, 'r', Background);
            PinkGhost = new Ghost(Pink, 'p', Background);
            List<BitmapImage> PacPics = new List<BitmapImage> { new BitmapImage(new Uri(@"pack://application:,,,/" + System.Reflection.Assembly.GetExecutingAssembly().GetName().Name + ";component/" + "/Resources/Up.gif", UriKind.Absolute)), new BitmapImage(new Uri(@"pack://application:,,,/" + System.Reflection.Assembly.GetExecutingAssembly().GetName().Name + ";component/" + "/Resources/down.gif", UriKind.Absolute)),
                 new BitmapImage(new Uri(@"pack://application:,,,/" + System.Reflection.Assembly.GetExecutingAssembly().GetName().Name + ";component/" + "/Resources/Left.gif", UriKind.Absolute)),new BitmapImage(new Uri(@"pack://application:,,,/" + System.Reflection.Assembly.GetExecutingAssembly().GetName().Name + ";component/" + "/Resources/Right.gif", UriKind.Absolute)) };

            One = new Player(PacPics, Background, MsPac);
            SC = new List<BitmapImage> { new BitmapImage(new Uri(@"pack://application:,,,/" + System.Reflection.Assembly.GetExecutingAssembly().GetName().Name + ";component/" + "/Resources/cccc.gif", UriKind.Absolute)),
                new BitmapImage(new Uri(@"pack://application:,,,/" + System.Reflection.Assembly.GetExecutingAssembly().GetName().Name + ";component/" + "/Resources/coin.gif", UriKind.Absolute)),
                new BitmapImage(new Uri(@"pack://application:,,,/" + System.Reflection.Assembly.GetExecutingAssembly().GetName().Name + ";component/" + "/Resources/coint2.gif", UriKind.Absolute))};
       

        }




        public void DispatcherTimer_Tick(object sender, EventArgs e)
        {
            YellowGhost.Move();
            PinkGhost.Move();
            RedGhost.Move();
            One.Move(Move);
            SUper.Spin();
            Collision();
            Output.Content = $"Don't let the Ghosts \n GET YOU!! \n Level: {Level} \n Points: {One.Points} \n Lives: {One.Lives}";
            if (One.Lives == 0)
            {
                Endgame();
            }
        }

        private Image MakeImage(string name, string tag)
        {//Creates an image dynamically
            Image x = new Image();
            x.Name = name;
            x.Visibility = Visibility.Visible;
            x.Height = 25;
            x.Width = 25;
            x.Tag = tag;
            this.Background.Children.Add(x);
            return x;
        }
        private void Endgame()
        {
            theTimer.IsEnabled = false;
            Output.Content = $"Great Job! Your Final Score: {One.Points}";
        }
        private void Window_KeyDown(object sender, KeyEventArgs e)
        {

        }

        private void Background_KeyDown(object sender, KeyEventArgs e)
        {
        }

        private void Window_KeyDown_1(object sender, KeyEventArgs e)
        {
            if (Starter)
            {
                switch (e.Key)
                {
                    case Key.Left:
                        Move = 'l';
                        break;
                    case Key.Right:
                        Move = 'r';
                        break;
                    case Key.Up:
                        Move = 'u'; break;
                    case Key.Down:
                        Move = 'd'; break;
                    case Key.P:
                        if (theTimer.IsEnabled)
                        {
                            theTimer.IsEnabled = false;
                        }
                        else theTimer.IsEnabled = true;
                        break;
                    case Key.S: Move = 's'; break;
                    default: Move = 's'; break;
                }
            }

        }

        private void Start_Click(object sender, RoutedEventArgs e)
        {
            Starter = true;
            Level = 1;
            MakeLevel();
            theTimer.IsEnabled = true;
            Output.Content = $"Don't let the Ghosts \n GET YOU!! \n Level: {Level} \n Points: {One.Points}";

        }
        private void MakeLevel()
        {
            Random r = new Random();
            int d = r.Next(800);
            int k = r.Next(500);
            int y = 0;
            SUper = new PacMan.SuperCoin(MakeImage("Super", "supercoin"), SC, Background, MakeImage("Key", "keys"), d, k);
            switch (Level)
            {
                case 1:
                    {
  
                        RedGhost.X = 10;
                        RedGhost.Y = 10;
                        YellowGhost.X = 10;
                        YellowGhost.Y = 10;
                        PinkGhost.X = 10;
                        PinkGhost.Y = 10;                     
                        SUper.Pic.Visibility = Visibility.Visible;
                        y = 10;
                       
                        break;
                    }
                case 2:
                    {
                        if (One.Points < 17000)
                        {
                            One.Die();
                        }
                        RedGhost.X = 15;
                        RedGhost.Y = 15;
                        YellowGhost.X = 15;
                        YellowGhost.Y = 15;
                        PinkGhost.X = 15;
                        PinkGhost.Y = 15;
                        y = 15;
                        break;
                    }
                case 3:
                    {
                        if (One.Points < 35000)
                        {
                            One.Die();
                        }
                        RedGhost.X = 20;
                        RedGhost.Y = 20;
                        YellowGhost.X = 20;
                        YellowGhost.Y = 20;
                        PinkGhost.X = 20;
                        PinkGhost.Y = 20;
                        y = 20;
                        break;
                    }
                case 4:
                    {
                        theTimer.IsEnabled = false;
                        Endgame();
                        break;
                    }
            }
            for (int x = 0; x < y; x++)
            {
                d = r.Next(800);
                k = r.Next(500);
                Coins.Add(new PacMan.Coin(MakeImage($"coin{x}", "coin"), SC, Background, d, k));

            }
        }
        private void DeleteLevel()
        {
            foreach (Coin c in Coins)
            {
                if (c.Pic.Tag.ToString() != "coin")
                {
                    this.Background.Children.Remove(c.Pic);
                }
                Coins.Remove(c);
            }
            this.Background.Children.Remove(SUper.Pic);
            SUper = null;
            
        }
        private void Collision()
        {
            var x1 = Canvas.GetLeft(MsPac);
            var y1 = Canvas.GetTop(MsPac);
            Rect r1 = new Rect(x1, y1, MsPac.ActualWidth, MsPac.ActualHeight);

            foreach (Coin x in Coins)
            {
            var x2 = Canvas.GetLeft(x.Pic);
            var y2 = Canvas.GetTop(x.Pic);
            Rect r2 = new Rect(x2, y2, x.Pic.ActualWidth, x.Pic.ActualHeight);
                if (r1.IntersectsWith(r2))
                {
                    One.PointsUp(x.points);
                    x.Pic.IsEnabled = false;
                    x.Pic.Visibility = Visibility.Hidden;
                }
            }

            var x3 = Canvas.GetLeft(SUper.Pic);
            var y3 = Canvas.GetTop(SUper.Pic);
            Rect r3 = new Rect(x3, y3, SUper.Pic.ActualWidth, SUper.Pic.ActualHeight);
            if (r1.IntersectsWith(r3))
            {
                One.PointsUp(SUper.points);

                SUper.MakeKey(new BitmapImage(new Uri(@"pack://application:,,,/" + System.Reflection.Assembly.GetExecutingAssembly().GetName().Name + ";component/" + "/Resources/key.png", UriKind.Absolute)));
                this.Background.Children.Remove(SUper.Pic);
            }
             x3 = Canvas.GetLeft(Red);
             y3 = Canvas.GetTop(Red);
             r3 = new Rect(x3, y3, Red.ActualWidth, Red.ActualHeight);
            if (r1.IntersectsWith(r3))
            {
                One.Die();
            }
            x3 = Canvas.GetLeft(Red);
            y3 = Canvas.GetTop(Red);
            r3 = new Rect(x3, y3, Red.ActualWidth, Red.ActualHeight);
            if (r1.IntersectsWith(r3))
            {
                One.Die();
            }
            x3 = Canvas.GetLeft(Yellow);
            y3 = Canvas.GetTop(Yellow);
            r3 = new Rect(x3, y3, Yellow.ActualWidth, Yellow.ActualHeight);
            if (r1.IntersectsWith(r3))
            {
                One.Die();
            }
            x3 = Canvas.GetLeft(Pink);
            y3 = Canvas.GetTop(Pink);
            r3 = new Rect(x3, y3, Pink.ActualWidth, Pink.ActualHeight);
            if (r1.IntersectsWith(r3))
            {
                One.Die();
            }
            x3 = Canvas.GetLeft(SUper.Key);
            y3 = Canvas.GetTop(SUper.Key);
            r3 = new Rect(x3, y3, SUper.Key.ActualWidth, SUper.Key.ActualHeight);
            if (r1.IntersectsWith(r3))
            {
                Level++;
                theTimer.IsEnabled = false;
                DeleteLevel();
                MakeLevel();
                this.Background.Children.Remove(SUper.Key);
            }

        }
    }
}


